<?php
require_once('functions/DB.class.php');

$db = new DB();
