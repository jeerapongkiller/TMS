<?php

class DB {
    private $db_servername = 'mysql';
    private $db_username = 'mytms';
    private $db_password = 'secret';
    private $db_name = 'tmsdb';

    public function __construct()
    {
        $connect_db = new mysqli($this->db_servername, $this->db_username, $this->db_password, $this->db_name);
        $connect_db->set_charset('utf8mb4');

        if ($connect_db->connect_error) {
            die("Connection failed: " . $connect_db->connect_error);
        } else {
            return true;
        }
    }
}